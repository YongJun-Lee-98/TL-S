fn main() {
    let s = "Hello, World!";
    println!("{}", s);
}

