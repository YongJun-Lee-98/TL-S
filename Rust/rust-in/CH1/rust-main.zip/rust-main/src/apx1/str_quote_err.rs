
fn main() {
    // 에러
    let s = 'Hello, World!';
    println!('{}', s);
}

