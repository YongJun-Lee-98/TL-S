fn main() {
    let year = 2023;
    let month = 12;
    let day = 1;
    println!("{yy}년 {mm}월 {dd}일", 
             dd=day, mm=month, yy=year);
}