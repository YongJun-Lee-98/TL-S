fn main() {
    let s = "안녕하세요";
    println!("{}",s[0]); // 직접 n번째 문자를 가져올 수 없다.
}