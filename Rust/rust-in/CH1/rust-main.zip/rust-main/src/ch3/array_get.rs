fn main() {
    let month = ["Jan", "Feb", "Mar", "Apl", "May"];
    println!("{}", month[0]); // Jan
    println!("{}", month[1]); // Feb
}