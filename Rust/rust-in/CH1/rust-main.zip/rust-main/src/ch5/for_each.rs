fn main() {
    let notes = [60,64,67,64, 60,64,67,72];
    for no in notes {
        // 노트를 하나씩 출력
        println!("{}", no);
    }
}
