// 러스트에서 변수를 문자열에 대입해 표시
fn main() {
    let banana = 300;
    println!("바나나 가격={}원", banana);
}

