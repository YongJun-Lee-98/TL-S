# 파이썬에서 변수를 문자열에 대입해 표시
banana = 300
print("바나나 가격={}원".format(banana))

