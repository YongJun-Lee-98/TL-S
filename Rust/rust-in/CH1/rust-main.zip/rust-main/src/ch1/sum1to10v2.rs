fn main() {
    let mut total = 0;
    for i in 1..=10 {
        total += i;
    }
    println!("{}", total);
}

