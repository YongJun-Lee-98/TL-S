fn main() {
    let mut total = 0;
    for i in 1..11 {
        total += i;
    }
    println!("{}", total);
}

