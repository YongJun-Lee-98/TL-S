// 에러 발생
fn main() {
    let a = 100;
    a = a + 1;
    println!("a is {}", a);
}

