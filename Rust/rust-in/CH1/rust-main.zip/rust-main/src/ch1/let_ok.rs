// 에러를 수정한 코드
fn main() {
    let mut a = 100; // 가변 변수 a를 정의
    a = a + 1; // 가변 변수이므로 값 변경이 가능
    println!("a is {}", a);
}
