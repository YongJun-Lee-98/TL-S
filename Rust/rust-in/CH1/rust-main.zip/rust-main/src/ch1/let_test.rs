fn main() {
    let dog = 100;
    let cat = 200;
    println!("dog is {}, cat is {}", dog, cat);
}

