moon = 384400
car = 80
btrain = 300
print("달까지 자동차로 {}일".format(moon / car / 24))
print("달까지 KTX로 {}일".format(moon / btrain / 24))

