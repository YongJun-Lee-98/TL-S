// (주의) 에러가 발생하는 소스 코드
fn main() {
    let v: u128 = 1234;
    println!("{}", v.pow(5678));
}

