fn main() {
    let nums = vec![1, 2, 3];
    println!("{:?}", nums);
}


