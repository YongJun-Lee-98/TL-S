# 주사위를 5번 굴리기
import random
for i in range(0, 5):
    dice = random.randint(1, 6)
    print(dice)

