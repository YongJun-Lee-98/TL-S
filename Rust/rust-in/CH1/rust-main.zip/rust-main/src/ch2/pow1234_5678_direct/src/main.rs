fn main() {
    let v = num_bigint::BigInt::from(1234);
    println!("{}", v.pow(5678));
}
