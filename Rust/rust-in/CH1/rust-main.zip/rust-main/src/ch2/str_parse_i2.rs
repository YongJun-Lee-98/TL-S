fn main() {
    let s = "365";
    let i: i32 = s.parse().unwrap();
    println!("{}", i);
}

