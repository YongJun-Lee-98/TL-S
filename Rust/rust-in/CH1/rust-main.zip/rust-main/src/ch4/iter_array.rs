fn main() {
    let array = [1, 3, 5, 7];
    for a in array {
        println!("{}", a);
    }
    println!("len={}", array.len());
}