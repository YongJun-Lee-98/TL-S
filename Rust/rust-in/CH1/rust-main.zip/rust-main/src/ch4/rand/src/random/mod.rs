pub mod linear;
pub mod xorshift;