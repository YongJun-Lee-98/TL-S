#[no_mangle]
pub extern "C" fn rust_mul(a: isize, b: isize) -> isize {
    a * b
}